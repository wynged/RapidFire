﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RapidFire.UI.Mock
{
    public class MockShortcutVM
    {
        public string NodeName
        {
            get
            {
                return "Node Node Name";
            }
        }

        public string ShortcutKey
        {
            get
            {
                return "KS";
            }
            set
            {
            }
        }
    }
}
